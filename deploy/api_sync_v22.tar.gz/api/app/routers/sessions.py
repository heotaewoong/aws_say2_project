"""진단 세션 라우터.

문서: §5.6, §6.3 — Phase 1~5 비동기 파이프라인 트리거 + 폴링 조회.

엔드포인트:
  POST   /api/v1/sessions             · 새 세션 생성 (Step Functions 시작 X)
  POST   /api/v1/sessions/{id}/run    · 파이프라인 실행 시작 (202 Accepted)
  GET    /api/v1/sessions/{id}        · 세션 상태 + Phase 결과 (frontend 가 2초 간격 polling)
  GET    /api/v1/sessions/{id}/result · 최종 통합 리포트
  POST   /api/v1/sessions/{id}/rerun  · 재진단 (새 세션 생성)

ORM ↔ Production schema 매핑 (2026-05-18 정렬):
  - DiagnosisSession.session_id (PK) ← 기존 .id
  - DiagnosisSession.patient_id      ← frontend payload.patient_fhir_id 그대로 저장
  - DiagnosisSession.initiated_by    ← clinician.id
  - frontend payload symptom_text/cxr_s3_key/execution_arn 은 phase_states JSONB 에 metadata 로 저장
    (DB 에 직접 컬럼 없음 — clinical_note/imaging_study 등 별도 테이블에 두는 v1.1 의도)
  - DiagnosisSession.initiated_at ← created_at, .completed_at ← updated_at (응답 매핑 용)
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from ...shared.db_models import (
    DiagnosisSession, FinalRagReport,
    Phase1Result, Phase2Result, Phase3Result, Phase4Result, Phase5Result,
)
from ...shared.schemas import (
    SessionCreateRequest, SessionCreateResponse,
    SessionDetailResponse, SessionFinalReport, SessionStatus,
)
from ..config import Settings
from ..deps import Clinician, get_current_clinician, get_db
from ..services.audit_log import log_session_access
from ..services.stepfunctions import start_diagnosis_pipeline

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/sessions", tags=["sessions"])


# ----------------------------------------------------------------
# Status 매핑 (frontend 'created' ↔ DB 'initiated')
# ----------------------------------------------------------------
# DB CHECK constraint: ('initiated','running','completed','failed','cancelled')
# Pydantic enum SessionStatus: 'created' 도 같이 받지만 DB 저장 시 'initiated' 로 변환.
_TO_DB_STATUS = {
    "created":   "initiated",
    "initiated": "initiated",
    "running":   "running",
    "completed": "completed",
    "failed":    "failed",
    "cancelled": "cancelled",
}
_FROM_DB_STATUS = {
    "initiated": SessionStatus.created,   # frontend 호환
    "running":   SessionStatus.running,
    "completed": SessionStatus.completed,
    "failed":    SessionStatus.failed,
    "cancelled": SessionStatus.cancelled,
}


def _settings() -> Settings:
    return Settings.from_env()


def _progress_from_phases(*phases) -> float:
    done = sum(1 for p in phases if p is not None)
    return round(done / max(1, len(phases)), 2)


async def _latest_bundle_id(db: AsyncSession, patient_id: str):
    """diagnosis_session.bundle_id (NOT NULL, FK raw_emr_bundle) 채우기.

    환자의 최신 raw_emr_bundle 사용. 없으면 mock-emr seeder 가 안 돌았다는 뜻 — 404.
    """
    row = (await db.execute(
        text(f"SELECT bundle_id FROM rarelinkai.raw_emr_bundle "
             f"WHERE patient_id=:pid ORDER BY fetched_at DESC LIMIT 1"),
        {"pid": patient_id},
    )).first()
    if not row:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            f"No EMR bundle for patient {patient_id} (seed mock-emr first)",
        )
    return row[0]


# ================================================================
# POST /sessions  — 새 세션 생성
# ================================================================
@router.post("", response_model=SessionCreateResponse, status_code=status.HTTP_201_CREATED)
async def create_session(
    payload: SessionCreateRequest,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
) -> SessionCreateResponse:
    # frontend 가 보낸 symptom_text/cxr_s3_key 는 phase_states JSONB 에 metadata 로 저장.
    # DB 의 patient_id 는 frontend.patient_fhir_id 그대로 사용 (FHIR Patient.id == EMR patient_id).
    bundle_id = await _latest_bundle_id(db, payload.patient_fhir_id)
    # session_id 를 미리 생성 — commit 후 ORM attribute access 가 expire 트리거하는 것을 회피.
    new_session_id = uuid.uuid4()
    sess = DiagnosisSession(
        session_id=new_session_id,
        patient_id=payload.patient_fhir_id,
        bundle_id=bundle_id,
        initiated_by=clinician.id,
        status="initiated",
        current_phase=0,
        phase_states={
            "frontend_payload": {
                "symptom_text": payload.symptom_text,
                "cxr_s3_key":   payload.cxr_s3_key,
            },
            "execution_arn": None,
        },
    )
    db.add(sess)
    await db.commit()

    await log_session_access(db,
                             clinician_id=clinician.id,
                             session_id=new_session_id,
                             patient_fhir_id=payload.patient_fhir_id,
                             action="session.create")

    return SessionCreateResponse(session_id=str(new_session_id),
                                 status=SessionStatus.created)


# ================================================================
# POST /sessions/{id}/run  — Step Functions 실행 시작
# ================================================================
@router.post("/{session_id}/run", status_code=status.HTTP_202_ACCEPTED)
async def run_session(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
) -> dict[str, Any]:
    sess: DiagnosisSession | None = await db.get(DiagnosisSession, session_id)
    if sess is None or sess.initiated_by != clinician.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")

    payload_meta = (sess.phase_states or {}).get("frontend_payload", {})
    s = _settings()
    arn = await start_diagnosis_pipeline(
        session_id=str(sess.session_id),
        patient_fhir_id=sess.patient_id,
        symptom_text=payload_meta.get("symptom_text") or "",
        cxr_s3_key=payload_meta.get("cxr_s3_key"),
        state_machine_arn=s.stepfn_state_machine_arn,
        region=s.aws_region,
    )

    sess.status = "running"
    sess.current_phase = 1
    new_states = dict(sess.phase_states or {})
    new_states["execution_arn"] = arn
    sess.phase_states = new_states
    await db.commit()

    await log_session_access(db,
                             clinician_id=clinician.id,
                             session_id=sess.session_id,
                             action="session.run",
                             payload={"execution_arn": arn})

    return {"status": "started", "execution_arn": arn}


# ================================================================
# GET /sessions/{id}  — 진행상태 + Phase 결과 (2초 polling)
# ================================================================
@router.get("/{session_id}", response_model=SessionDetailResponse)
async def get_session(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
) -> SessionDetailResponse:
    sess: DiagnosisSession | None = await db.get(DiagnosisSession, session_id)
    if sess is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")
    if sess.initiated_by != clinician.id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Forbidden")

    # 각 phase 의 최신 row (composite PK 라 같은 session 에 여러 row 가능 — rerun 등)
    p1 = await db.scalar(
        select(Phase1Result).where(Phase1Result.session_id == session_id)
        .order_by(Phase1Result.executed_at.desc())
    )
    p2 = await db.scalar(
        select(Phase2Result).where(Phase2Result.session_id == session_id)
        .order_by(Phase2Result.executed_at.desc())
    )
    p3 = await db.scalar(
        select(Phase3Result).where(Phase3Result.session_id == session_id)
        .order_by(Phase3Result.executed_at.desc())
    )
    p4 = await db.scalar(
        select(Phase4Result).where(Phase4Result.session_id == session_id)
        .order_by(Phase4Result.executed_at.desc())
    )
    p5 = await db.scalar(
        select(Phase5Result).where(Phase5Result.session_id == session_id)
        .order_by(Phase5Result.executed_at.desc())
    )

    await log_session_access(db,
                             clinician_id=clinician.id,
                             session_id=sess.session_id,
                             action="session.read_status")

    return SessionDetailResponse(
        session_id=str(sess.session_id),
        patient_fhir_id=sess.patient_id,
        status=_FROM_DB_STATUS.get(sess.status, SessionStatus.failed),
        progress=_progress_from_phases(p1, p2, p3, p4, p5),
        phase1=_to_phase1(p1) if p1 else None,
        phase2=_to_phase2(p2) if p2 else None,
        phase3=_to_phase3(p3) if p3 else None,
        phase4=_to_phase4(p4) if p4 else None,
        phase5=_to_phase5(p5) if p5 else None,
        created_at=sess.initiated_at,
        updated_at=sess.completed_at or sess.initiated_at,
    )


# ================================================================
# GET /sessions/{id}/result  — 최종 RAG 리포트
# ================================================================
@router.get("/{session_id}/result", response_model=SessionFinalReport)
async def get_session_result(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
) -> SessionFinalReport:
    sess: DiagnosisSession | None = await db.get(DiagnosisSession, session_id)
    if sess is None or sess.initiated_by != clinician.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")

    # final_report 는 (session_id, generated_at) composite PK — 가장 최근 1건.
    final: FinalRagReport | None = await db.scalar(
        select(FinalRagReport).where(FinalRagReport.session_id == session_id)
        .order_by(FinalRagReport.generated_at.desc())
    )
    if final is None:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "Final report not yet ready. Poll /sessions/{id} until status=completed.")

    await log_session_access(db,
                             clinician_id=clinician.id,
                             session_id=sess.session_id,
                             action="session.read_result")

    # diagnosis_json 에서 final_dx · confidence 추출 (RAG handler 가 채워 넣음)
    diag = final.diagnosis_json or {}
    final_dx = diag.get("final_dx") or diag.get("primary_diagnosis")
    confidence = diag.get("confidence")

    from ...shared.schemas import RagCitation
    citations = [RagCitation(**c) for c in (final.rag_citations or [])]

    md = final.markdown_report or ""

    return SessionFinalReport(
        session_id=str(sess.session_id),
        patient_fhir_id=sess.patient_id,
        final_dx=final_dx,
        confidence=confidence,
        diagnosis_json=diag,
        markdown_report=md,
        full_report_md=md,                                   # backwards-compat alias
        rag_citations=citations,
        rag_apis_used=list(final.rag_apis_used or []),
        self_check=final.self_check,
        llm_model=final.llm_model,
        s3_uri_pdf=final.s3_uri_pdf,
        generated_at=final.generated_at,
    )


# ================================================================
# POST /sessions/{id}/rerun  — 같은 환자/증상으로 새 세션
# ================================================================
@router.post("/{session_id}/rerun",
             response_model=SessionCreateResponse,
             status_code=status.HTTP_201_CREATED)
async def rerun_session(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
) -> SessionCreateResponse:
    """재진단 = 같은 환자/증상으로 새 세션 생성. 원본 세션은 history 보존."""
    orig: DiagnosisSession | None = await db.get(DiagnosisSession, session_id)
    if orig is None or orig.initiated_by != clinician.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Session not found")

    orig_payload = (orig.phase_states or {}).get("frontend_payload", {})
    new = DiagnosisSession(
        patient_id=orig.patient_id,
        bundle_id=orig.bundle_id,
        initiated_by=clinician.id,
        status="initiated",
        current_phase=0,
        phase_states={
            "frontend_payload": orig_payload,
            "execution_arn": None,
            "rerun_of": str(session_id),
        },
    )
    db.add(new)
    await db.commit()
    await db.refresh(new)

    await log_session_access(db,
                             clinician_id=clinician.id,
                             session_id=new.session_id,
                             action="session.rerun",
                             payload={"original_session_id": str(session_id)})

    return SessionCreateResponse(session_id=str(new.session_id),
                                 status=SessionStatus.created)


# ================================================================
# ORM (production schema) → Pydantic schemas 변환
# ================================================================
def _to_phase1(p: Phase1Result):
    from ...shared.schemas import Phase1Result as S
    return S(
        positive_hpo=p.positive_hpo or [],
        negative_hpo=p.negative_hpo or [],
        extracted_at=p.executed_at,
    )


def _to_phase2(p: Phase2Result):
    """phase2_xray_processing.densenet_findings → Phase2Result.findings.

    densenet_findings shape (Lambda 가 INSERT 하는 형식):
      [{label, score}, ...]  또는  {label1: score1, ...}
    cxr_s3_key 는 s3_original_full 로 매핑.
    """
    from ...shared.schemas import Phase2Finding, Phase2Result as S
    raw = p.densenet_findings or []
    findings: list[Phase2Finding] = []
    if isinstance(raw, list):
        for f in raw:
            if isinstance(f, dict) and "label" in f and "score" in f:
                try:
                    findings.append(Phase2Finding(label=str(f["label"]),
                                                  score=float(f["score"])))
                except (TypeError, ValueError):
                    continue
    elif isinstance(raw, dict):
        for k, v in raw.items():
            try:
                findings.append(Phase2Finding(label=str(k), score=float(v)))
            except (TypeError, ValueError):
                continue
    return S(
        findings=findings,
        cxr_s3_key=p.s3_original_full,
        inferred_at=p.executed_at,
    )


def _to_phase3(p: Phase3Result):
    """phase3_integrated_ranking.ranking → Phase3Result.top_candidates (top N).

    ranking shape (phase3-scorer Lambda 가 INSERT — DiagnosticScorer.score_all):
      [{disease_key/disease_id, name/name_kr, score/total_score, orpha_code, ...}, ...]
    """
    from ...shared.schemas import Phase3LRScore, Phase3Result as S
    raw = p.ranking or []
    cands: list[Phase3LRScore] = []
    for d in (raw if isinstance(raw, list) else []):
        if not isinstance(d, dict):
            continue
        name = d.get("name") or d.get("name_kr") or d.get("disease_key") or d.get("disease_id") or ""
        orpha = d.get("orpha_code") or d.get("orphacode") or d.get("orpha")
        score = d.get("lr_score") or d.get("score") or d.get("total_score") or 0.0
        try:
            cands.append(Phase3LRScore(orpha_code=orpha,
                                       name=str(name),
                                       lr_score=float(score)))
        except (TypeError, ValueError):
            continue
    return S(top_candidates=cands[:10], computed_at=p.executed_at)


def _to_phase4(p: Phase4Result):
    """phase4_llm_rerank.reranked → Phase4Result.verifications.

    reranked shape (phase4-verifier Lambda 가 INSERT):
      [{candidate/disease_key, confidence, evidence/reasoning, ...}, ...]
    """
    from ...shared.schemas import Phase4Result as S, Phase4Verification
    raw = p.reranked or []
    vs: list[Phase4Verification] = []
    for v in (raw if isinstance(raw, list) else []):
        if not isinstance(v, dict):
            continue
        cand = v.get("candidate") or v.get("disease_key") or v.get("name") or ""
        conf = (v.get("confidence") or "MEDIUM").upper()
        ev = v.get("evidence") or v.get("reasoning") or []
        if isinstance(ev, str):
            ev = [ev]
        try:
            vs.append(Phase4Verification(candidate=str(cand),
                                         confidence=conf,
                                         evidence=list(ev) if isinstance(ev, list) else []))
        except (TypeError, ValueError):
            continue
    return S(verifications=vs, verified_at=p.executed_at)


def _to_phase5(p: Phase5Result):
    """ORM (phase5_rare_disease_listing) → Pydantic Phase5Result (rare listing)."""
    from ...shared.schemas import Phase5Result as S, RareDiseaseListing
    listed = []
    for d in (p.listed_diseases or []):
        if not isinstance(d, dict):
            continue
        try:
            listed.append(RareDiseaseListing(**d))
        except Exception:
            # 누락 필드는 default 로 채워지지만 잘못된 타입 entry 는 skip
            continue
    return S(
        listed_diseases=listed,
        total_listed_count=p.total_listed_count or len(listed),
        top_lr_score=float(p.top_lr_score) if p.top_lr_score is not None else None,
        top_lr_orphacode=p.top_lr_orphacode,
        listing_criteria=p.listing_criteria or {},
        rare_db_version=p.rare_db_ver,
        executed_at=p.executed_at,
    )
